function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5W1TngZsAek":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

